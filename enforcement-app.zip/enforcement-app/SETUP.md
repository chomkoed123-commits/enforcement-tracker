# วิธี Deploy ระบบ Enforcement Tracker (Neon + Netlify)

## โครงสร้างไฟล์
```
enforcement-app/
├── netlify.toml                    ← config หลัก
├── package.json                    ← dependencies
├── public/
│   └── index.html                  ← หน้าเว็บ
└── netlify/
    └── functions/
        └── cases.js                ← API (คุยกับ Neon)
```

---

## STEP 1 — ตั้งค่า Neon Database

1. ไปที่ https://console.neon.tech
2. คลิก **"New Project"** → ตั้งชื่อ เช่น `lucky-leasing`
3. Region เลือก **Singapore** (ใกล้ไทย)
4. หลัง project สร้างเสร็จ จะเห็นหน้า Dashboard
5. คลิก **"Connection Details"**
6. เลือก **Connection string** → Copy ค่าที่ขึ้นต้นด้วย:
   ```
   postgresql://username:password@ep-xxx.ap-southeast-1.aws.neon.tech/neondb?sslmode=require
   ```
7. เก็บ string นี้ไว้ก่อน (ใช้ใน Step 3)

---

## STEP 2 — Upload ไฟล์ขึ้น Netlify

### วิธี A: Drag & Drop + GitHub (แนะนำ)

1. ไปที่ https://github.com → สร้าง repo ใหม่ชื่อ `enforcement-tracker`
2. Upload ไฟล์ทั้งหมดในโฟลเดอร์ `enforcement-app/` ขึ้น repo
3. ไปที่ https://app.netlify.com
4. คลิก **"Add new site"** → **"Import an existing project"**
5. เลือก GitHub → เลือก repo `enforcement-tracker`
6. Build settings:
   - **Publish directory**: `public`
   - **Functions directory**: `netlify/functions`
7. คลิก **"Deploy site"**

### วิธี B: Drag & Drop อย่างเดียว (ง่ายกว่า แต่อัพเดทได้ยากกว่า)

1. ไปที่ https://app.netlify.com → เลือก site ที่มีอยู่
2. ไปที่ tab **"Deploys"**
3. ลาก **โฟลเดอร์** `enforcement-app/` ทั้งโฟลเดอร์ (ไม่ใช่แค่ไฟล์) วางใน Drop zone

---

## STEP 3 — ตั้งค่า Environment Variable

1. ใน Netlify → Site → **"Site configuration"**
2. คลิก **"Environment variables"**
3. คลิก **"Add a variable"**
4. ใส่:
   - **Key**: `DATABASE_URL`
   - **Value**: (วาง connection string จาก Step 1)
5. คลิก **"Save"**
6. **Redeploy site** (Deploys → Trigger deploy)

---

## STEP 4 — Import ข้อมูล Excel เข้า Neon (ครั้งแรกเท่านั้น)

1. เปิดเว็บที่ deploy ไว้
2. เปิด Browser Console (กด F12 → Console)
3. พิมพ์แล้วกด Enter:
   ```javascript
   seedDatabase()
   ```
4. คลิก OK เพื่อยืนยัน
5. รอจน Console แสดง `Seeded 357/357`
6. Reload หน้า — ข้อมูลจะแสดงขึ้นมาทันที

---

## STEP 5 — ทดสอบ

เปิด URL ของ site แล้วตรวจสอบ:
- [ ] KPI แสดงตัวเลขถูกต้อง (357 คดี)
- [ ] แก้ไขเคส → reload → ข้อมูลยังอยู่ ✓
- [ ] เปิดจากมือถือหรือเครื่องอื่น → เห็นข้อมูลเดียวกัน ✓

---

## การอัพเดท Feature ในอนาคต

### ถ้าใช้ GitHub (Step 2A):
1. ขอ feature ใหม่จาก Claude → Download ไฟล์ใหม่
2. แทนที่ไฟล์ใน GitHub repo
3. Netlify จะ deploy ให้อัตโนมัติ (ภายใน 1 นาที)

### ถ้าใช้ Drag & Drop (Step 2B):
1. ขอ feature ใหม่จาก Claude → Download ไฟล์ใหม่
2. ไปที่ Netlify → Deploys → ลากโฟลเดอร์ใหม่วางทับ

> ⚠️ ข้อมูลใน Neon ไม่ได้รับผลกระทบจากการ redeploy ไฟล์

---

## Troubleshooting

| ปัญหา | วิธีแก้ |
|-------|---------|
| หน้าเว็บขึ้น "โหลดไม่ได้" | ตรวจว่าตั้ง `DATABASE_URL` ใน Netlify แล้ว + Redeploy |
| Function timeout | Neon region ไม่ใช่ Singapore → สร้าง project ใหม่ |
| ข้อมูลหาย | ดู Neon console → ตรวจ table `enforcement_cases` |
| บันทึกไม่ขึ้น | เปิด F12 → Network → ดู error จาก `/api/` calls |
